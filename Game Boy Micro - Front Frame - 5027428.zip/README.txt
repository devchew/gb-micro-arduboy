Game Boy Micro - Front Frame by makho on Thingiverse: https://www.thingiverse.com/thing:5027428

Summary:
Made from Heff87's scan -- I reworked most of the mesh to make it 3D printable and actually able to be assembled. I still need to make the screw holes a wee bit bigger but otherwise it's 100% functional as a replacement for the front frame, faceplate clips and all. All buttons working: https://gfycat.com/adolescenttornearwigI highly recommend SLA or SLS printing. This is not an FDM friendly shape. 